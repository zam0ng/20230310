// ES6 문법으로 작성
import express from "express"

const app = express();
app.listen(3000,()=>{
    console.log("server on");
})