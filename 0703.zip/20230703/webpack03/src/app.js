import React from "react";

class App extends React.Component {
    render(){
        return <div>안녕</div>
    }
}
export default App;

// export default App class App extends React.Component {
//     render()
//     {
//         return <div>안녕</div>
//     }
// }

