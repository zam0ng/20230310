import "./index.css"
// css 파일을 가져옴

console.log("시작!");